﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using KitchenSoft.Models;

namespace KitchenSoft.Controllers
{
    public class CookingController : Controller
    {
        private KitchenViewModel KitchenModel;

        public CookingController(KitchenViewModel model)
        {
            KitchenModel = model;
        }

        public ViewResult Index() => View("Kitchen", new KitchenViewModel());


        [HttpPost]
        public ViewResult UpdateTypes(string tp1, string tp2, string tp3, string tp4, string f1, string f2, string f3, string f4)
        {
            KitchenModel.Type1 = tp1;
            KitchenModel.Type2 = tp2;
            KitchenModel.Type3 = tp3;
            KitchenModel.Type4 = tp4;
            if (f1 != "None")
            {
                Food theFood = FakeFoodRepository.Foods.Where(f => f.BaseName == f1).First();
                KitchenModel.Ingredient1 = theFood;
            }
            if (f2 != "None")
            {
                Food theFood = FakeFoodRepository.Foods.Where(f => f.BaseName == f2).First();
                KitchenModel.Ingredient2 = theFood;
            }
            if (f3 != "None")
            {
                Food theFood = FakeFoodRepository.Foods.Where(f => f.BaseName == f3).First();
                KitchenModel.Ingredient3 = theFood;
            }
            if (f4 != "None")
            {
                Food theFood = FakeFoodRepository.Foods.Where(f => f.BaseName == f4).First();
                KitchenModel.Ingredient4 = theFood;
            }
            return View("Kitchen", KitchenModel);
        }
    }
}
