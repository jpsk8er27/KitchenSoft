﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public class EFFoodRepository : IFoodRepository
    {
        private FoodDBContext context;

        public EFFoodRepository(FoodDBContext ctx)
        {
            context = ctx;
        }

        public IQueryable<Food> Foods => context.Foods;
    }
}
