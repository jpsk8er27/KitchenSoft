﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public static class FakeFoodRepository
    {
        public static IQueryable<Food> Foods => new List<Food>
        {
            new Food {BaseName = "Apple", Calories = 70, Types = new List<string> { "Fruit" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Red", "White"} },
            new Food {BaseName = "Brocolli", Calories = 35, Types = new List<string> { "Vegetable" }, Flavors = new List<string> { "Bitter" }, Colors = new List<string> { "Green"} },
            new Food {BaseName = "Bacon", Calories = 180, Types = new List<string> { "Meat" }, Flavors = new List<string> { "Savory" }, Colors = new List<string> { "Red", "Brown"} },
            new Food {BaseName = "Cinnamon", Calories = 20, Types = new List<string> { "Seasoning" }, Flavors = new List<string> { "Sweet", "Spicy" }, Colors = new List<string> { "Red"} },
            new Food {BaseName = "Mango", Calories = 85, Types = new List<string> { "Fruit" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Red", "Yellow"} },
            new Food {BaseName = "Provolone", Calories = 110, Types = new List<string> { "Dairy" }, Flavors = new List<string> { "Creamy" }, Colors = new List<string> { "White"} },
            new Food {BaseName = "Rye Bread", Calories = 80, Types = new List<string> { "Grains" }, Flavors = new List<string> { "Savory", "Dry" }, Colors = new List<string> { "Red", "White"} },
            new Food {BaseName = "Skittles", Calories = 110, Types = new List<string> { "Sweets" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Red", "Green", "Orange", "Purple", "Yellow"} },
            new Food {BaseName = "Sprite", Calories = 140, Types = new List<string> { "Beverage" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Clear"} }
        }.AsQueryable<Food>();
    }
}
