﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public class FlavorRepository
    {
        List<string> Flavors => new List<string>
        {
            "Sweet",
            "Sour",
            "Salty",
            "Savory",
            "Bitter",
            "Creamy",
            "Meaty",
            "Chemical",
            "Rotten",
            "Pungent",
            "Dry",
            "Spicy"
        };
    }
}
