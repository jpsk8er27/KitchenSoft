﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.ModelBinding;


namespace KitchenSoft.Models
{
    public class Food
    {
        public Food() { }

        public Food(int id, string name, int cals, string tp, List<string> flavs, List<string> cols)
        {
            FoodId = id;
            BaseName = name;
            Calories = cals;
            Types.Append(tp);
            Flavors = flavs;
            Colors = cols;
        }

        public Food(string name, int cals)
        {
            BaseName = name;
            Calories = cals;
        }

        public string Name
        {
            get
            {
                if(Preparations != null && Preparations.ToList().Count > 0)
                {
                    string line = "";
                    foreach(string prep in Preparations)
                    {
                        if(prep == "Boiled" || prep == "Fried" || prep == "Frilled" || prep == "Baked" || prep == "Smoked")
                        {
                            line = prep + " " + line;
                        }
                        else
                        {
                            line += prep + " ";
                        }
                    }
                    line += BaseName;
                    return line;
                }
                else
                {
                    return BaseName;
                }
            }
        }

        
        public int FoodId { get; set; }

        public string BaseName { get; set; }

        public int Calories { get; set; }

        public List<string> Types { get; set; }

        public List<string> Flavors { get; set; }

        public List<string> Colors { get; set; }

        public List<string> Preparations { get; set; }

        //Combine Sweet with other flavors
        public List<string> AddSweet(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach(string flv in flavs)
            {
                if(flv == "Sweet")
                {
                    comboFlavors.Add("Sweet");
                }
                else if(flv == "Sour")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Sour");
                }
                else if(flv == "Salty")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Salty");
                }
                else if(flv == "Savory")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Savory");
                }
                else if(flv == "Bitter")
                {
                    comboFlavors.Add("Pungent");
                }
                else if(flv == "Creamy")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Creamy");
                }
                else if(flv == "Meaty")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Savory");
                }
                else if(flv == "Chemical")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Chemical");
                }
                else if(flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if(flv == "Pungent")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Pungent");
                }
                else if(flv == "Spicy")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Spicy");
                }
                else if(flv == "Dry")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Sweet");
                }
            }
            return comboFlavors;
        }

        //Combine sour with other flavors
        public List<string> AddSour(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Sour");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Sour");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Sour");
                }
            }
            return comboFlavors;
        }

        //Combine salty with other flavors
        public List<string> AddSalty(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Bitter");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Creamy");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Meaty");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Salty");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Salty");
                }
            }
            return comboFlavors;
        }

        //Combine savory with other flavors
        public List<string> AddSavory(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Creamy");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Meaty");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Savory");
                }
            }
            return comboFlavors;
        }

        //Combine bitter with other flavors
        public List<string> AddBitter(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Bitter");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Creamy");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Meaty");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Bitter");
                }
            }
            return comboFlavors;
        }

        //Combine creamy with other flavors
        public List<string> AddCreamy(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Sweet");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Bitter");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Creamy");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Savory");
                }
                else
                {
                    comboFlavors.Add("Creamy");
                }
            }
            return comboFlavors;
        }

        //Combine meaty with other flavors
        public List<string> AddMeaty(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Sweet");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Bitter");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Creamy");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Meaty");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Meaty");
                }
            }
            return comboFlavors;
        }

        //Combine chemical with other flavors
        public List<string> AddChemical(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Sweet");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Chemical");
                }
            }
            return comboFlavors;
        }

        //Combine rotten with other flavors
        public List<string> AddRotten(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Rotten");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Rotten");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Rotten");
                }
                else
                {
                    comboFlavors.Add("Rotten");
                }
            }
            return comboFlavors;
        }

        //Combine pungent with other flavors
        public List<string> AddPungent(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Sweet");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Savory");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Dry");
                    comboFlavors.Add("Spicy");
                }
                else
                {
                    comboFlavors.Add("Pungent");
                }
            }
            return comboFlavors;
        }

        //Combine dry with other flavors
        public List<string> AddDry(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Dry");
                    comboFlavors.Add("Sweet");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Sour");
                    comboFlavors.Add("Dry");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Dry");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Dry");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Dry");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Dry");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Dry");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Dry");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Dry");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Dry");
                }
            }
            return comboFlavors;
        }

        //Combine spicy with other flavors
        public List<string> AddSpicy(List<string> flavs)
        {
            List<string> comboFlavors = new List<string>();
            foreach (string flv in flavs)
            {
                if (flv == "Sweet")
                {
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Sweet");
                }
                else if (flv == "Sour")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Salty")
                {
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Salty");
                }
                else if (flv == "Savory")
                {
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Savory");
                }
                else if (flv == "Bitter")
                {
                    comboFlavors.Add("Bitter");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Chemical");
                }
                else if (flv == "Creamy")
                {
                    comboFlavors.Add("Creamy");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Meaty")
                {
                    comboFlavors.Add("Meaty");
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Chemical")
                {
                    comboFlavors.Add("Chemical");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Rotten")
                {
                    comboFlavors.Add("Rotten");
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Pungent")
                {
                    comboFlavors.Add("Pungent");
                }
                else if (flv == "Spicy")
                {
                    comboFlavors.Add("Spicy");
                }
                else if (flv == "Dry")
                {
                    comboFlavors.Add("Spicy");
                    comboFlavors.Add("Dry");
                }
                else
                {
                    comboFlavors.Add("Spicy");
                }
            }
            return comboFlavors;
        }

        //Combine all flavors in food
        public void CombineFlavors()
        {
            List<string> newFlavors = new List<string>();
            List<string> tempFlavors = new List<string>();

            foreach(string flav in Flavors)
            {
                if(flav == "Sweet")
                {
                    tempFlavors = AddSweet(Flavors);
                    foreach(string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Sour")
                {
                    tempFlavors = AddSour(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Salty")
                {
                    tempFlavors = AddSalty(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Savory")
                {
                    tempFlavors = AddSavory(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Bitter")
                {
                    tempFlavors = AddBitter(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Creamy")
                {
                    tempFlavors = AddCreamy(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Meaty")
                {
                    tempFlavors = AddSalty(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Chemical")
                {
                    tempFlavors = AddChemical(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Rotten")
                {
                    tempFlavors = AddRotten(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Pungent")
                {
                    tempFlavors = AddPungent(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Spicy")
                {
                    tempFlavors = AddSpicy(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
                else if (flav == "Dry")
                {
                    tempFlavors = AddDry(Flavors);
                    foreach (string flv in tempFlavors)
                    {
                        newFlavors.Add(flv);
                    }
                }
            }
            //Thin to one of each flavor
            bool hasSweet = false;
            bool hasSour = false;
            bool hasSalty = false;
            bool hasSavory = false;
            bool hasBitter = false;
            bool hasCreamy = false;
            bool hasMeaty = false;
            bool hasChemical = false;
            bool hasRotten = false;
            bool hasPungent = false;
            bool hasSpicy = false;
            bool hasDry = false;

            tempFlavors.Clear();

            foreach (string flv in newFlavors)
            {
                if(flv == "Sweet")
                {
                    if(!hasSweet)
                    {
                        tempFlavors.Add(flv);
                        hasSweet = true;
                    }
                }
                else if (flv == "Sour")
                {
                    if (!hasSour)
                    {
                        tempFlavors.Add(flv);
                        hasSour = true;
                    }
                }
                else if (flv == "Salty")
                {
                    if (!hasSalty)
                    {
                        tempFlavors.Add(flv);
                        hasSalty = true;
                    }
                }
                else if (flv == "Savory")
                {
                    if (!hasSavory)
                    {
                        tempFlavors.Add(flv);
                        hasSavory = true;
                    }
                }
                else if (flv == "Bitter")
                {
                    if (!hasBitter)
                    {
                        tempFlavors.Add(flv);
                        hasBitter = true;
                    }
                }
                else if (flv == "Creamy")
                {
                    if (!hasCreamy)
                    {
                        tempFlavors.Add(flv);
                        hasCreamy = true;
                    }
                }
                else if (flv == "Meaty")
                {
                    if (!hasMeaty)
                    {
                        tempFlavors.Add(flv);
                        hasMeaty = true;
                    }
                }
                else if (flv == "Chemical")
                {
                    if (!hasChemical)
                    {
                        tempFlavors.Add(flv);
                        hasChemical = true;
                    }
                }
                else if (flv == "Rotten")
                {
                    if (!hasRotten)
                    {
                        tempFlavors.Add(flv);
                        hasRotten = true;
                    }
                }
                else if (flv == "Pungent")
                {
                    if (!hasPungent)
                    {
                        tempFlavors.Add(flv);
                        hasPungent = true;
                    }
                }
                else if (flv == "Spicy")
                {
                    if (!hasSpicy)
                    {
                        tempFlavors.Add(flv);
                        hasSpicy = true;
                    }
                }
                else if (flv == "Dry")
                {
                    if (!hasDry)
                    {
                        tempFlavors.Add(flv);
                        hasDry = true;
                    }
                }
            }
            Flavors = tempFlavors;
        }

        public void CombineColors()
        {
            //Determine color of food
        }

        // Determine how preparations affect calories
        public virtual void CalculateCalories()
        {
            int baseCals = Calories;
            foreach(string prep in Preparations)
            {
                if(prep == "Boiled")
                {
                    Calories += Convert.ToInt32((baseCals * 0.1));
                }
                else if (prep == "Fried")
                {
                    Calories += Convert.ToInt32((baseCals * 0.2));
                }
                else if (prep == "Grilled")
                {
                    Calories += Convert.ToInt32((baseCals * 0.05));
                }
                else if (prep == "Baked")
                {
                    Calories += Convert.ToInt32((baseCals * 0.1));
                }
                else if (prep == "Smoked")
                {
                    Calories += Convert.ToInt32((baseCals * 0.05));
                }
            }
        }

    }
}
