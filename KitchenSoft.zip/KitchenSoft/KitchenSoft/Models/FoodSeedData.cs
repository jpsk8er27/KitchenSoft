﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace KitchenSoft.Models
{
    public static class FoodSeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            FoodDBContext context = app.ApplicationServices.GetRequiredService<FoodDBContext>();
            context.Database.Migrate();
            if(!context.Foods.Any())
            {
                context.Foods.AddRange(
                    new Food { FoodId = 1, BaseName = "Apple", Calories = 70, Types = new List<string> { "Fruit" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Red", "White" } },
                    new Food { FoodId = 2, BaseName = "Brocolli", Calories = 35, Types = new List<string> { "Vegetable" }, Flavors = new List<string> { "Bitter" }, Colors = new List<string> { "Green" } },
                    new Food { FoodId = 3, BaseName = "Bacon", Calories = 180, Types = new List<string> { "Meat" }, Flavors = new List<string> { "Savory" }, Colors = new List<string> { "Red", "Brown" } },
                    new Food { FoodId = 4, BaseName = "Provolone", Calories = 110, Types = new List<string> { "Dairy" }, Flavors = new List<string> { "Creamy" }, Colors = new List<string> { "White" } },
                    new Food { FoodId = 5, BaseName = "Rye Bread", Calories = 80, Types = new List<string> { "Grains" }, Flavors = new List<string> { "Savory", "Dry" }, Colors = new List<string> { "Red", "White" } },
                    new Food { FoodId = 6, BaseName = "Skittles", Calories = 110, Types = new List<string> { "Sweets" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Red", "Green", "Orange", "Purple", "Yellow" } },
                    new Food { FoodId = 7, BaseName = "Cinnamon", Calories = 20, Types = new List<string> { "Seasoning" }, Flavors = new List<string> { "Sweet", "Spicy" }, Colors = new List<string> { "Red" } },
                    new Food { FoodId = 8, BaseName = "Sprite", Calories = 140, Types = new List<string> { "Beverages" }, Flavors = new List<string> { "Sweet" }, Colors = new List<string> { "Clear" } }
                    );
                context.SaveChanges();
            }
        }
    }
}
