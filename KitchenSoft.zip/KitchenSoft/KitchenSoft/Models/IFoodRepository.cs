﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public interface IFoodRepository
    {
        IQueryable<Food> Foods { get; }
    }
}
