﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public class KitchenViewModel
    {
        public string Type1 { get; set; }

        public string Type2 { get; set; }

        public string Type3 { get; set; }

        public string Type4 { get; set; }

        public Food Ingredient1 { get; set; }

        public Food Ingredient2 { get; set; }

        public Food Ingredient3 { get; set; }

        public Food Ingredient4 { get; set; }

        public Meal CookedMeal { get; set; }

        public KitchenViewModel()
        {
            Type1 = "None";
            Type2 = "None";
            Type3 = "None";
            Type4 = "None";
            Ingredient1 = new Food("None", 0);
            Ingredient2 = new Food("None", 0);
            Ingredient3 = new Food("None", 0);
            Ingredient4 = new Food("None", 0);
        }
    }
}
