﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public class Meal : Food
    {
        public List<Food> Ingredients { get; set; }

        public string FinalPrep { get; set; }

        public string DetermineName()
        {
            string mealName = "";
            mealName += FinalPrep + " ";
            for(int i = 0; i < Ingredients.Count; i++)
            {
                if(i != Ingredients.Count - 1)
                {
                    mealName += Ingredients[i].BaseName + ", ";
                }
                else
                {
                    mealName += "and " + Ingredients[i].BaseName;
                }
            }
            return mealName;
        }

        public override void CalculateCalories()
        {
            foreach(Food ing in Ingredients)
            {
                Calories += ing.Calories;
                if (FinalPrep == "Boiled")
                {
                    Calories = Convert.ToInt32((Calories * 1.1));
                }
                else if (FinalPrep == "Fried")
                {
                    Calories = Convert.ToInt32((Calories * 1.2));
                }
                else if (FinalPrep == "Grilled")
                {
                    Calories = Convert.ToInt32((Calories * 1.05));
                }
                else if (FinalPrep == "Baked")
                {
                    Calories = Convert.ToInt32((Calories * 1.1));
                }
                else if (FinalPrep == "Smoked")
                {
                    Calories = Convert.ToInt32((Calories * 1.05));
                }
            }
        }
    }
}
