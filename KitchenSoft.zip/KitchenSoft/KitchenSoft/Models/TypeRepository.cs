﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public static class TypeRepository
    {
        public static List<string> Types => new List<string>
        {
            "Fruit",
            "Vegetable",
            "Meat",
            "Dairy",
            "Grains",
            "Sweets",
            "Seasoning",
            "Beverage"
        };
    }
}
