﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KitchenSoft.Models
{
    public class User
    {
        public User(string em, string pass)
        {
            Email = em;
            Password = pass;
        }

        public string Email { get; set; }

        public string Password { get; set; }

        public List<Food> MyFoods { get; set; }

        public string[] StatNames = { "Items Cooked", "Favorite Food Type", "Favorite Flavor" };

        public string[] StatVals = { "", "", "" };

        public void DetermineFavorites()
        {

        }
    }
}
